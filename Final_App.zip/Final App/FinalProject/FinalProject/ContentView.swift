import SwiftUI

struct ContentView: View {
    let names = [
        "Aatrox", "Akshan", "Akali", "Camile", "ChoGath","Darius", "Dr.Mundo", "Fiora", "Gangplank", "Garen", "Gnar", "Gragas", "Graves", "Gwen", "Illaoi", "Irelia", "Jax", "Jayce", "Ksante","Kayle", "Kennen", "Kled","Malphite", "Maokai", "Mordekaiser", "Nasus", "Olaf", "Ornn", "Pantheon", "Poppy", "Quinn", "Renekton", "Rengar", "Riven", "Rumble", "Sett", "Shen", "Singed", "Sion", "Sylas", "TahmKench", "Teemo", "Trundle", "Tryndamere", "Udyr", "Urgot", "Varus", "Vayne", "Vladimir", "Volibear", "Warwick", "Wukong", "Yasuo", "Yone", "Yorick", "Zac",
        
    ]
    
    @State private var selectedName: String = ""
    @State private var confirmationMessage: String = ""
    @State private var isNameConfirmed: Bool = false

    var body: some View {
        NavigationView {
            VStack {
                Text("Top Counters")
                    .fontWeight(.bold)
                    .font(.largeTitle)
                    .foregroundColor(.black)
                Text("Enter in a Top Lane champion")
                    .foregroundColor(.black)
                    
                Image("default_image")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 100)
                    .padding()
                Link("List of Champions", destination: URL(string: "https://u.gg/lol/top-lane-tier-list")!)
                    .foregroundColor(Color.init(red:0.02, green: 0.212, blue: 0.29))
                    .font(.headline)
                TextField("Select a name", text: $selectedName)
                  
                    .padding()
                    .disableAutocorrection(true)
                

                NavigationLink(destination: AnotherView(selectedName: $selectedName, isNameConfirmed: $isNameConfirmed, confirmationMessage: $confirmationMessage), isActive: $isNameConfirmed) {
                    Button(action: {
                        self.confirmSelection()
                    }) {
                        Text("Confirm")
                            .padding()
                            .foregroundColor(.black)
                            .background(Color.init(red:0.855, green: 1, blue: 0.964))
                            .cornerRadius(10)
                    }
                }
                .background(Color.clear)
                .navigationBarHidden(true)

                Text(confirmationMessage)
                    .padding()
                    .foregroundColor(.red)
            }
            .padding()
            .navigationBarTitle("Champion Selector", displayMode: .inline)
        }
    }

    private func confirmSelection() {
        if names.contains(selectedName) {
            isNameConfirmed = true
        } else {
            confirmationMessage = "Invalid selection"
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
