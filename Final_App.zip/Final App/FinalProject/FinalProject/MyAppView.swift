import SwiftUI

struct AnotherView: View {
    let sPlus = ["Jax", "Fiora", "Malphite", "Trundle", "Darius", "Illaoi", "Riven", "Camile"]
    let normalS = ["Nasus", "Olaf", "Garen", "Irelia", "Poppy", "Tryndamere"]
    let normalA = ["Ornn", "Singed", "Quinn", "Sylas", "Vayne", "Rengar", "Akshan", "Warwick", "Kled", "Kayle", "Urgot", "TahmKench", "Dr.Mundo", "Vladimir", "Zac", "Udyr"]
    let normaB = ["Shen", "Maokai", "Aatrox", "Wukong", "Gragas", "Gwen", "ChoGath", "Gnar", "Pantheon", "Teemo", "Volibear", "Kennen"]
    let normalC = ["Varus", "Sett", "Rumble", "Ksante", "Gangplank", "Mordikaiser"]
    let normalD = ["Renekton", "Yasuo", "Yorick", "Sion", "Akali", "Jayce", "Yone"]

    @Binding var selectedName: String
    @Binding var isNameConfirmed: Bool
    @Binding var confirmationMessage: String
    @State private var isNextViewActive = false

    var body: some View {
        VStack {
            Text("\(selectedName)")
                .font(.largeTitle)
                .fontWeight(.bold)
            Image(selectedName)
                .resizable()
                .frame(width: 100, height: 100)


            let letterRanking: String = {
                switch selectedName {
                case let champion where sPlus.contains(champion):
                    return "S+"
                case let champion where normalS.contains(champion):
                    return "S"
                case let champion where normalA.contains(champion):
                    return "A"
                case let champion where normaB.contains(champion):
                    return "B"
                case let champion where normalC.contains(champion):
                    return "C"
                case let champion where normalD.contains(champion):
                    return "D"
                default:
                    return "Unknown"
                }
            }()


            Text("Letter Ranking: \(letterRanking)")
                .foregroundColor(getColor(for: letterRanking))

            NavigationLink(
                destination: NextView(selectedName: $selectedName),
                isActive: $isNextViewActive
            ) {
                Button(action: {
                    isNextViewActive = true
                }) {
                    Text("\(selectedName) Counters")
                        .padding()
                        .foregroundColor(.black)
                        .background(Color.init(red:0.855, green: 1, blue: 0.964))
                        .cornerRadius(10)
                    
                }
            }
        }
    
    }


    func getColor(for ranking: String) -> Color {
        switch ranking {
        case "S+":
            return .purple
        case "S":
            return .green
        case "A":
            return .blue
        case "B":
            return .yellow
        case "C":
            return .red
        case "D":
            return .gray
        default:
            return .black
        }
    }
    
}


