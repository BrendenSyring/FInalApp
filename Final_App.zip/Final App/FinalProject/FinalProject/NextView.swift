import SwiftUI
import HTMLKit

struct NextView: View {
    struct CharacterInfo: Identifiable {
        let id: UUID
        let name: String
        let imageName: String
        
    }

    @State private var characters: [CharacterInfo] = Array(repeating: CharacterInfo(id: UUID(), name: "Loading...", imageName: ""), count: 3)
    @Binding var selectedName: String

    var body: some View {
        Text("\(selectedName) Counters")
            .fontWeight(.bold)
            .font(.largeTitle)
        VStack {
            ForEach(characters) { character in
                HStack {
                    Image("\(character.name)")
                        .frame(width: 100, height: 100)
                        .padding()
                    Text(character.name)
                        .padding()
                }
            }
        }
        .task {
            await loadWebPage()
        }
    }

    func loadWebPage() async {
        guard let url = URL(string: "https://u.gg/lol/champions/\(selectedName)/build/top") else {
            print("Invalid URL")
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let html = try? String(data: data, encoding: .utf8) {
                let parser = HTMLParser(string: html)
                if let bodyElement = parser.document.body {
                    let strongElements = bodyElement.querySelectorAll("div.champion-name")
                    for (index, strongElement) in (strongElements ?? []).enumerated() {
                        if index < 3 {
                            let name = strongElement.textContent ?? "Name not found"
                            let character = CharacterInfo(id: UUID(), name: name, imageName: "exampleImage")
                            characters[index] = character
                        }
                    }
                }
            }
        } catch {
            print("Invalid Data or HTMLKit parsing error!")
        }
    }
}
